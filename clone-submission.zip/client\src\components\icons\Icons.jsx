export function AirbnbLogo({ className = "h-8 w-[102px]" }) {
  return (
    <svg viewBox="0 0 1024 1024" className={className} aria-label="Airbnb homepage" role="img">
      <path
        fill="currentColor"
        d="M512 0C229.2 0 0 229.2 0 512s229.2 512 512 512 512-229.2 512-512S794.8 0 512 0zm163.3 724.6c-2.5 4.3-7.1 6.9-12.1 6.9-2.5 0-5-.7-7.2-2.1-68.4-43.8-137.3-132.4-163.3-173.8h-.2c-26 41.4-94.9 130-163.3 173.8-2.2 1.4-4.7 2.1-7.2 2.1-5 0-9.6-2.6-12.1-6.9-3.6-6.3-1.5-14.3 4.8-17.9 31.6-18.1 64.3-49.8 94.6-86.3-51.8-59.6-83.8-123.8-83.8-166.8 0-62.6 40.8-105.5 96.6-105.5 44.8 0 82.1 32.8 96.6 81.1 14.5-48.3 51.8-81.1 96.6-81.1 55.8 0 96.6 42.9 96.6 105.5 0 43-32 107.2-83.8 166.8 30.3 36.5 63 68.2 94.6 86.3 6.3 3.6 8.4 11.6 4.8 17.9z"
      />
    </svg>
  );
}

export function AirbnbWordmark({ className = "h-8 w-[102px] fill-current" }) {
  return (
    <svg viewBox="0 0 3490 1080" className={className} aria-hidden="true">
      <path d="M1494.71 456.953C1458.28 412.178 1408.46 389.892 1349.68 389.892C1233.51 389.892 1146.18 481.906 1146.18 605.892C1146.18 729.877 1233.51 821.892 1349.68 821.892C1408.46 821.892 1458.28 799.605 1494.71 754.83L1500.95 810.195H1589.84V401.588H1500.95L1494.71 456.953ZM1369.18 736.895C1295.33 736.895 1242.08 683.41 1242.08 605.892C1242.08 528.373 1295.33 474.888 1369.18 474.888C1443.02 474.888 1495.49 529.153 1495.49 605.892C1495.49 682.63 1443.8 736.895 1369.18 736.895ZM1656.11 810.195H1750.46V401.588H1656.11V810.195ZM948.912 666.715C875.618 506.859 795.308 344.664 713.438 184.809C698.623 155.177 670.554 98.2527 645.603 67.8412C609.736 24.1733 556.715 0.779785 502.915 0.779785C449.115 0.779785 396.094 24.1733 360.227 67.8412C335.277 98.2527 307.207 155.177 292.392 184.809C210.522 344.664 130.212 506.859 56.9187 666.715C47.5621 687.769 24.9504 737.675 16.3736 760.289C6.2373 787.581 0.779297 817.213 0.779297 846.845C0.779297 975.509 101.362 1079.22 235.473 1079.22C346.193 1079.22 434.3 1008.26 502.915 934.18C571.53 1008.26 659.638 1079.22 770.357 1079.22C904.468 1079.22 1005.83 975.509 1005.83 846.845C1005.83 817.213 999.593 787.581 989.457 760.289C980.88 737.675 958.268 687.769 948.912 666.715ZM502.915 810.195C447.555 738.455 396.094 649.56 396.094 577.819C396.094 506.079 446.776 470.209 502.915 470.209C559.055 470.209 610.516 508.419 610.516 577.819C610.516 647.22 558.275 738.455 502.915 810.195ZM770.357 998.902C688.362 998.902 618.032 941.557 555.741 872.656C619.966 792.541 690.826 679.121 690.826 577.819C690.826 458.513 598.04 389.892 502.915 389.892C407.79 389.892 315.784 458.513 315.784 577.819C315.784 679.098 386.145 792.478 450.144 872.593C387.845 941.526 317.491 998.902 235.473 998.902C146.586 998.902 81.0898 931.061 81.0898 846.845C81.0898 826.57 84.2087 807.856 91.2261 788.361C98.2436 770.426 120.855 720.52 130.212 701.025C203.505 541.17 282.256 380.534 364.126 220.679C378.941 191.047 403.891 141.921 422.605 119.307C442.877 94.3538 470.947 81.0975 502.915 81.0975C534.883 81.0975 562.953 94.3538 583.226 119.307C601.939 141.921 626.89 191.047 641.704 220.679C723.574 380.534 802.325 541.17 875.618 701.025C884.975 720.52 907.587 770.426 914.604 788.361C921.622 807.856 925.52 826.57 925.52 846.845C925.52 931.061 859.244 998.902 770.357 998.902ZM3285.71 389.892C3226.91 389.892 3175.97 413.098 3139.91 456.953V226.917H3045.56V810.195H3134.45L3140.69 754.83C3177.12 799.605 3226.94 821.892 3285.71 821.892C3401.89 821.892 3489.22 729.877 3489.22 605.892C3489.22 481.906 3401.89 389.892 3285.71 389.892ZM3266.22 736.895C3191.6 736.895 3139.91 682.63 3139.91 605.892C3139.91 529.153 3191.6 474.888 3266.22 474.888C3340.85 474.888 3393.32 528.373 3393.32 605.892C3393.32 683.41 3340.07 736.895 3266.22 736.895ZM2827.24 389.892C2766.15 389.892 2723.56 418.182 2699.37 456.953L2693.13 401.588H2604.24V810.195H2698.59V573.921C2698.59 516.217 2741.47 474.888 2800.73 474.888C2856.87 474.888 2888.84 513.097 2888.84 578.599V810.195H2983.19V566.903C2983.19 457.733 2923.15 389.892 2827.24 389.892ZM1911.86 460.072L1905.62 401.588H1816.73V810.195H1911.08V604.332C1911.08 532.592 1954.74 486.585 2027.26 486.585C2042.85 486.585 2058.44 488.144 2070.92 492.043V401.588C2059.22 396.91 2044.41 395.35 2028.04 395.35C1978.58 395.35 1936.66 421.177 1911.86 460.072ZM2353.96 389.892C2295.15 389.892 2244.21 413.098 2208.15 456.953V226.917H2113.8V810.195H2202.69L2208.93 754.83C2245.36 799.605 2295.18 821.892 2353.96 821.892C2470.13 821.892 2557.46 729.877 2557.46 605.892C2557.46 481.906 2470.13 389.892 2353.96 389.892ZM2334.46 736.895C2259.84 736.895 2208.15 682.63 2208.15 605.892C2208.15 529.153 2259.84 474.888 2334.46 474.888C2409.09 474.888 2461.56 528.373 2461.56 605.892C2461.56 683.41 2408.31 736.895 2334.46 736.895ZM1703.28 226.917C1669.48 226.917 1642.08 254.326 1642.08 288.13C1642.08 321.934 1669.48 349.343 1703.28 349.343C1737.09 349.343 1764.49 321.934 1764.49 288.13C1764.49 254.326 1737.09 226.917 1703.28 226.917Z" />
    </svg>
  );
}

export const IconSearch = (p) => (
  <svg viewBox="0 0 32 32" fill="none" aria-hidden="true" {...p}>
    <path d="M13.5 4a9.5 9.5 0 1 1 0 19 9.5 9.5 0 0 1 0-19Zm0 3a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13ZM26.7 25.3l-5.8-5.8 2.1-2.1 5.8 5.8-2.1 2.1Z" fill="currentColor" />
  </svg>
);

export const IconHeart = ({ filled, ...p }) => (
  <svg viewBox="0 0 32 32" aria-hidden="true" {...p}>
    <path
      fill={filled ? "#ff385c" : "none"}
      stroke={filled ? "#ff385c" : "currentColor"}
      strokeWidth="2"
      d="M16 28c-1.2 0-2.3-.4-3.2-1.1C8.4 23.8 4 19.4 4 14.6 4 11 6.8 8 10.4 8c2 0 3.8.9 5 2.4C16.6 8.9 18.4 8 20.4 8 24 8 26.8 11 26.8 14.6c0 4.8-4.4 9.2-8.8 12.3-.9.7-2 1.1-3.2 1.1Z"
    />
  </svg>
);

export const IconShare = (p) => (
  <svg viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true" {...p}>
    <circle cx="22" cy="8" r="3" />
    <circle cx="8" cy="16" r="3" />
    <circle cx="22" cy="24" r="3" />
    <path d="M10.8 14.5 19.2 9.5M10.8 17.5l8.4 5" />
  </svg>
);

export const IconGlobe = (p) => (
  <svg viewBox="0 0 16 16" fill="currentColor" aria-hidden="true" {...p}>
    <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0ZM1.3 8c0-1 .2-1.9.6-2.8h2.6c-.1.9-.2 1.8-.2 2.8s.1 1.9.2 2.8H1.9A6.7 6.7 0 0 1 1.3 8Zm5 6.6c-.6-1.1-1-2.4-1.2-3.8h3.8c-.2 1.4-.6 2.7-1.2 3.8A6.6 6.6 0 0 1 6.3 14.6Zm1.7-5.8H4.9c-.1-.9-.1-1.8-.1-2.8s0-1.9.1-2.8h6.2c.1.9.1 1.8.1 2.8s0 1.9-.1 2.8H8Zm2.5 5.8c.6-1.1 1-2.4 1.2-3.8H7.9c.2 1.4.6 2.7 1.2 3.8.4.2.9.4 1.4.4s1-.1 1.4-.4Zm2.6-4.8c.1-.9.2-1.8.2-2.8s-.1-1.9-.2-2.8h2.6c.4.9.6 1.8.6 2.8s-.2 1.9-.6 2.8h-2.6Z" />
  </svg>
);

export const IconMenu = (p) => (
  <svg viewBox="0 0 32 32" fill="currentColor" aria-hidden="true" {...p}>
    <path d="M2 8h28v3H2V8zm0 7h28v3H2v-3zm0 7h28v3H2v-3z" />
  </svg>
);

export const IconUser = (p) => (
  <svg viewBox="0 0 32 32" fill="currentColor" aria-hidden="true" {...p}>
    <path d="M16 16a6 6 0 1 0 0-12 6 6 0 0 0 0 12zm0 3c-6.1 0-11 4-11 9h22c0-5-4.9-9-11-9z" />
  </svg>
);

export const IconChevron = ({ dir = "left", ...p }) => (
  <svg viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="3" aria-hidden="true" {...p}>
    {dir === "left" && <path d="M20 6 10 16l10 10" />}
    {dir === "right" && <path d="M12 6l10 10-10 10" />}
    {dir === "down" && <path d="M6 12l10 10 10-10" />}
  </svg>
);

export const IconGrid = (p) => (
  <svg viewBox="0 0 16 16" fill="currentColor" aria-hidden="true" {...p}>
    <path d="M1 1h6v6H1V1zm8 0h6v6H9V1zM1 9h6v6H1V9zm8 0h6v6H9V9z" />
  </svg>
);

export const IconStar = (p) => (
  <svg viewBox="0 0 12 12" fill="currentColor" aria-hidden="true" {...p}>
    <path d="m6 1 1.5 3.1L11 4.6 8.5 7l.6 3.4L6 8.8 2.9 10.4 3.5 7 1 4.6l3.5-.5L6 1z" />
  </svg>
);

export const IconWifi = (p) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true" {...p}>
    <path d="M4.5 10.2a11 11 0 0 1 15 0M7.2 13.2a7 7 0 0 1 9.6 0M12 18.2h.01" />
  </svg>
);

export const IconKitchen = (p) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true" {...p}>
    <path d="M6 3v7a3 3 0 0 0 6 0V3M9 3v18M15 8h4v13h-4z" />
  </svg>
);

export const IconAc = (p) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true" {...p}>
    <path d="M4 8h16v6H4zM8 14v3M16 14v3M7 11h2M15 11h2" />
  </svg>
);

export const IconCar = (p) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true" {...p}>
    <path d="M4 16h16v3H4zM5 13l2-5h10l2 5M7 19a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zm10 0a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z" />
  </svg>
);

export const IconWasher = (p) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true" {...p}>
    <rect x="4" y="3" width="16" height="18" rx="2" />
    <circle cx="12" cy="13" r="4" />
    <circle cx="8" cy="6.5" r=".7" fill="currentColor" />
    <circle cx="10.5" cy="6.5" r=".7" fill="currentColor" />
  </svg>
);

export const IconTv = (p) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true" {...p}>
    <rect x="3" y="6" width="18" height="12" rx="2" />
    <path d="M8 21h8" />
  </svg>
);

export const IconKey = (p) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true" {...p}>
    <circle cx="8" cy="12" r="4" />
    <path d="M12 12h9v3h-3v2h-3v-2h-1" />
  </svg>
);

export const IconPin = (p) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true" {...p}>
    <path d="M12 21s7-6.2 7-11a7 7 0 1 0-14 0c0 4.8 7 11 7 11z" />
    <circle cx="12" cy="10" r="2.2" />
  </svg>
);

export const IconFlag = (p) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true" {...p}>
    <path d="M5 21V4h9l-1.2 4H19l-2 5H5" />
  </svg>
);

export const IconDiamond = (p) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true" {...p}>
    <path d="M6 8 12 4l6 4-6 12L6 8zM6 8h12" />
  </svg>
);

export const IconClose = (p) => (
  <svg viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="3" aria-hidden="true" {...p}>
    <path d="M8 8l16 16M24 8 8 24" />
  </svg>
);

export const IconHome = ({ filled, ...p }) => (
  <svg viewBox="0 0 32 32" aria-hidden="true" {...p}>
    <path
      fill={filled ? "currentColor" : "none"}
      stroke="currentColor"
      strokeWidth="1.8"
      d="M5 14.5 16 5l11 9.5V26a1 1 0 0 1-1 1h-7v-8h-6v8H6a1 1 0 0 1-1-1V14.5z"
    />
  </svg>
);

export const IconBalloon = (p) => (
  <svg viewBox="0 0 32 32" aria-hidden="true" {...p}>
    <ellipse cx="16" cy="13" rx="7.2" ry="8.2" fill="#ff5a5f" />
    <ellipse cx="16" cy="13" rx="7.2" ry="8.2" fill="none" stroke="#222" strokeWidth="1.2" />
    <path d="M13.2 20.6c.8 1.4 1.6 2 2.8 2s2-.6 2.8-2" fill="none" stroke="#222" strokeWidth="1.2" />
    <path d="M16 22.6v4.2M14.2 27.6h3.6" fill="none" stroke="#222" strokeWidth="1.4" strokeLinecap="round" />
    <path d="M16 5.2c1.8 2.4 2.6 5 2.6 7.8" fill="none" stroke="#fff" strokeWidth="1.2" opacity=".55" />
  </svg>
);

export const IconBell = (p) => (
  <svg viewBox="0 0 32 32" aria-hidden="true" {...p}>
    <path
      d="M8.5 21.5h15l-1.3-2.2A8 8 0 0 1 7.8 13V12a8.2 8.2 0 0 1 16.4 0v1"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
    />
    <path d="M13 22.2a3 3 0 0 0 6 0" fill="none" stroke="currentColor" strokeWidth="1.8" />
    <circle cx="23.2" cy="9.2" r="2.3" fill="#222" />
  </svg>
);

export const IconTinyHome = (p) => (
  <svg viewBox="0 0 16 16" aria-hidden="true" {...p}>
    <path fill="currentColor" d="M2.4 7.3 8 2.6l5.6 4.7V13a.7.7 0 0 1-.7.7H9.2V9.4H6.8V13.7H3.1A.7.7 0 0 1 2.4 13V7.3z" />
  </svg>
);

export const IconPhotos = (p) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true" {...p}>
    <rect x="3" y="5" width="18" height="14" rx="2" />
    <circle cx="8.5" cy="10" r="1.5" />
    <path d="m21 16-5-5-8 8" />
  </svg>
);

export const amenityIcon = (name) => {
  const n = name.toLowerCase();
  if (n.includes("wi-fi") || n.includes("wifi")) return IconWifi;
  if (n.includes("kitchen")) return IconKitchen;
  if (n.includes("air")) return IconAc;
  if (n.includes("parking") || n.includes("car")) return IconCar;
  if (n.includes("washer") || n.includes("laundry")) return IconWasher;
  if (n.includes("tv")) return IconTv;
  return IconHome;
};
